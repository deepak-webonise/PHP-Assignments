<?php
class DB extends PDO
{
	
	function __construct($host,$user='',$password='',$options=array())
	{
		try {
			parent::__construct($host,$user,$password,$options);
		}
 		catch (PDOException $e) {
   			 echo 'Connection failed: ' . $e->getMessage();
			 die();
		}
	}
	function insertUser($userData=array())
	{
		try 
		{			
			$stmt = parent::prepare("INSERT INTO users (firstName,lastName,email,password)VALUES(?,?,?,?)");
			$stmt->bindParam(1, $userData['firstName']);
			$stmt->bindParam(2, $userData['lastName']);
			$stmt->bindParam(3, $userData['email']);
			$stmt->bindParam(4, $userData['password']);
			$stmt->execute();
			return true;
			
		}
 		catch (PDOException $e) {
   			 echo 'Connection failed: ' . $e->getMessage();
			 die();
		}
	}
	function insertBook($bookData=array())
	{
		try 
		{			
			$stmt = parent::prepare("INSERT INTO books (name,author,publisher,description,bookshelfId)VALUES(?,?,?,?,?)");
			$stmt->bindParam(1, $bookData['name']);
			$stmt->bindParam(2, $bookData['author']);
			$stmt->bindParam(3, $bookData['publisher']);
			$stmt->bindParam(4, $bookData['description']);
			$stmt->bindParam(5, $bookData['bookshelfId']);
			$stmt->execute();
			return true;
			
		}
 		catch (PDOException $e) {
   			 echo 'Connection failed: ' . $e->getMessage();
			 die();
		}
	}
	function insertBookShelf($bookShelfData=array())
	{
		try 
		{			
			$stmt = parent::prepare("INSERT INTO bookshelf (name,uid)VALUES(?,?)");
			$stmt->bindParam(1, $bookShelfData['name']);
			$stmt->bindParam(2, $bookShelfData['uid']);
			$stmt->execute();
			return true;
			
		}
 		catch (PDOException $e) {
   			 echo 'Connection failed: ' . $e->getMessage();
			 die();
		}
	}
	function update($table,$argumnets= array(),$where)
	{
		try 
		{
			foreach ($argumnets as $column => $value) {
			parent::exec("UPDATE $table SET $column = $value WHERE $where");
			echo "UPDATE $table SET $column = $value WHERE $where";
			}
		}
 		catch (PDOException $e) {
   			 echo 'Connection failed: ' . $e->getMessage();
			 die();
		}
	}
	function checkUsernameExists($email) {
		try
		{
			$result = parent::exec("select id from users where email='$email'");
    		if(mysql_num_rows($result) == 0)
    		{
			return false;
	   		}else{
	   		return true;
			}
		}
 		catch (PDOException $e) {
   			 echo 'Connection failed: ' . $e->getMessage();
			 die();
		}
	}
	
}


$db = new DB('mysql:host=localhost;dbname=webo_book', "root", "", array(PDO::ATTR_PERSISTENT => true));
/*$temp = array('firstName'=>'dfg','lastName'=>'xyz','email'=>'abc@abc.com','password'=>'abc');
//$db->insertUser($temp);
$db->update("users",$temp,"1");*/
$data = array('name'=>'abc','author'=>'xyz','publisher'=>'sss','description'=>'aaaaaaa','bookshelfId'=>1);
$db->insertBook($data);


?>