<?php
require_once("DBClass.php");
require_once("validate.php");

?>