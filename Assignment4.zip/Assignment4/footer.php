		</div>
        <script src="js/bootstrap.min.js"></script>
        <p class="text-center">&copy 2014 Webonise Labs</p>
    </body>
    
</html>
